---
title: Egg fill
categories:
  - Real world
tags:
  - food
---
