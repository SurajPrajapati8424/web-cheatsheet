---
title: File minus
categories:
  - Files and folders
tags:
  - doc
  - document
  - delete
  - remove
---
