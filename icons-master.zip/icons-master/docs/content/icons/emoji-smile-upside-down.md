---
title: Emoji smile upside down
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - sarcasm
---
