---
title: Droplet fill
categories:
  - Graphics
tags:
  - water-drop
  - paint
  - ink
  - liquid
---
