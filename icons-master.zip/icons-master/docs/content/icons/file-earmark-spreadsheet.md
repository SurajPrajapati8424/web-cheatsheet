---
title: File earmark spreadsheet
categories:
  - Files and folders
tags:
  - doc
  - document
  - excel
  - table
---
