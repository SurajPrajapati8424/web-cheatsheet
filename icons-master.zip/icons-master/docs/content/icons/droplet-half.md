---
title: Droplet half
categories:
  - Graphics
tags:
  - water-drop
  - paint
  - ink
  - liquid
---
