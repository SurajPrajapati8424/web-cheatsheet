---
title: File zip
categories:
  - Files and folders
tags:
  - doc
  - document
  - zip
  - archive
  - compress
---
