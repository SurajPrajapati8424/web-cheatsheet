---
title: File person
categories:
  - Files and folders
tags:
  - doc
  - document
  - personal
  - cv
  - resume
  - about
---
