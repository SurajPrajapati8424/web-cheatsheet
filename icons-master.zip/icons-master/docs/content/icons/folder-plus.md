---
title: Folder plus
categories:
  - Files and folders
tags:
  - directory
  - delete
  - add
  - new
---
